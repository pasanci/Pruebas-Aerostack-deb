
"use strict";

let logThisString = require('./logThisString.js')

module.exports = {
  logThisString: logThisString,
};
