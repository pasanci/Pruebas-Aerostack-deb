px-ros-pkg
----------

A repository for PIXHAWK open source code running on ROS.

Notes:

1. The master branch uses catkin. If you wish to use rosbuild, please use the rosbuild branch.
