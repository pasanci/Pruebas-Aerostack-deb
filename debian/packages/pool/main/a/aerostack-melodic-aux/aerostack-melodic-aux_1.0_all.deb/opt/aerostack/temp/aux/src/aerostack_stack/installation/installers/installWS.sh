#!/bin/bash

#AEROSTACK_WORKSPACE
echo "export AEROSTACK_WORKSPACE=`pwd`" >> $HOME/.bashrc

