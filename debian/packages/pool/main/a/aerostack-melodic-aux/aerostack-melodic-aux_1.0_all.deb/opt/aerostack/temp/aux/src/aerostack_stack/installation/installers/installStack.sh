#!/bin/bash

#AEROSTACK_STACK
echo "export AEROSTACK_STACK=`pwd`" >> $HOME/.bashrc
