## Aerostack

Please visit the Aerostack Wikis for a complete project documentation:

* [Public Aerostack Wiki](https://github.com/Vision4UAV/Aerostack/wiki)

* [Private Aerostack Wiki](https://bitbucket.org/Vision4UAV/aerostack.git/wiki) (only for Aerostack developers)