# ros_lightware
A simple ROS serial driver for the lightware SF10 altimeter
Relies on cereal_port, a lightweight serial port handler, which has been catkinized and is available at https://github.com/stevenwaslander/cereal_port 