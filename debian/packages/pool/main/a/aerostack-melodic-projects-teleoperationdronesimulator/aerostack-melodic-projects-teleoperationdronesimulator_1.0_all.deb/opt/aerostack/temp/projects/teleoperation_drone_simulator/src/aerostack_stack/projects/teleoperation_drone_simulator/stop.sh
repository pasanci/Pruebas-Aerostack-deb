#!/bin/bash

pkill -SIGINT roslaunch
