
"use strict";

let BoundingBox = require('./BoundingBox.js');
let Target = require('./Target.js');

module.exports = {
  BoundingBox: BoundingBox,
  Target: Target,
};
