#!/bin/bash

cd $AEROSTACK_STACK
source setup.sh

roslaunch rotors_gazebo env_mav.launch



