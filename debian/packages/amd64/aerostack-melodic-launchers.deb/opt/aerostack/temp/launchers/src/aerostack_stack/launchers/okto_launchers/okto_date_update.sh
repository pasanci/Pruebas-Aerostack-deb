#!/bin/bash

./time_update.sh `date +%s`
