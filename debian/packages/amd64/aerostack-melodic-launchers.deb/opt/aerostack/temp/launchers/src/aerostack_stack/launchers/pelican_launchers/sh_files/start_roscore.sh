#! /bin/bash

cd $AEROSTACK_STACK
source setup.sh
roscore

