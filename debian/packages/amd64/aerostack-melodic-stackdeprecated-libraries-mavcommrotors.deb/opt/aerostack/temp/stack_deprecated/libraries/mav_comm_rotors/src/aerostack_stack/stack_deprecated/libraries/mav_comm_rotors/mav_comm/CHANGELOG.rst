^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package mav_comm
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
3.1.0 (2016-12-01)
------------------
* More helper functions, see mav_msgs_rotors changelog for details.

3.0.0 (2015-08-09)
------------------
* Changed API for mav_msgs_rotors, see mav_msgs_rotors changelog for details.

2.0.3 (2015-05-22)
------------------

