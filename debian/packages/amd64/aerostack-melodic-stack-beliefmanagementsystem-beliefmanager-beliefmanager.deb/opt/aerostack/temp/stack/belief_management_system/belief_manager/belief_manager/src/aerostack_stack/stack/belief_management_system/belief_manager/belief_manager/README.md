## belief_manager
This repository is the library for the Belief Manager.