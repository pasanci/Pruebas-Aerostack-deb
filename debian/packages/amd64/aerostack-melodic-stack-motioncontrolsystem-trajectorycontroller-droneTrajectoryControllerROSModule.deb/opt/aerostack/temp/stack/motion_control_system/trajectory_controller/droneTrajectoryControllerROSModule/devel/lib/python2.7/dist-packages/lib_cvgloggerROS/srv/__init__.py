from ._logThisString import *
