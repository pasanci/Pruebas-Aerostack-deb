^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package pugixml
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.7.1 (2016-03-06)
------------------
* updating license and readme
* adding compatibility without ROS
* minor info update. Still need to be updated properly
* upgraded to version 1.7 of pugixml and changed the name
* readme
* first commit
* Contributors: Jose Luis Sanchez Lopez, joselusl
