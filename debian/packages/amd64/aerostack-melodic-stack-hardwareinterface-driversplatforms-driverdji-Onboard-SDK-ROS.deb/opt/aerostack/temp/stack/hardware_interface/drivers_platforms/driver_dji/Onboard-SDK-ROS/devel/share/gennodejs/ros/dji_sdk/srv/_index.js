
"use strict";

let MissionHpResetYaw = require('./MissionHpResetYaw.js')
let SetupCameraStream = require('./SetupCameraStream.js')
let MissionWpAction = require('./MissionWpAction.js')
let CameraAction = require('./CameraAction.js')
let MFIOConfig = require('./MFIOConfig.js')
let MFIOSetValue = require('./MFIOSetValue.js')
let MissionHpAction = require('./MissionHpAction.js')
let DroneTaskControl = require('./DroneTaskControl.js')
let MissionHpUpdateRadius = require('./MissionHpUpdateRadius.js')
let MissionWpGetSpeed = require('./MissionWpGetSpeed.js')
let QueryDroneVersion = require('./QueryDroneVersion.js')
let MissionWpUpload = require('./MissionWpUpload.js')
let SendMobileData = require('./SendMobileData.js')
let MissionStatus = require('./MissionStatus.js')
let DroneArmControl = require('./DroneArmControl.js')
let MissionHpUpload = require('./MissionHpUpload.js')
let MissionHpGetInfo = require('./MissionHpGetInfo.js')
let SendPayloadData = require('./SendPayloadData.js')
let SetLocalPosRef = require('./SetLocalPosRef.js')
let SetHardSync = require('./SetHardSync.js')
let MissionWpGetInfo = require('./MissionWpGetInfo.js')
let Activation = require('./Activation.js')
let StereoVGASubscription = require('./StereoVGASubscription.js')
let MissionWpSetSpeed = require('./MissionWpSetSpeed.js')
let SDKControlAuthority = require('./SDKControlAuthority.js')
let StereoDepthSubscription = require('./StereoDepthSubscription.js')
let MissionHpUpdateYawRate = require('./MissionHpUpdateYawRate.js')
let Stereo240pSubscription = require('./Stereo240pSubscription.js')

module.exports = {
  MissionHpResetYaw: MissionHpResetYaw,
  SetupCameraStream: SetupCameraStream,
  MissionWpAction: MissionWpAction,
  CameraAction: CameraAction,
  MFIOConfig: MFIOConfig,
  MFIOSetValue: MFIOSetValue,
  MissionHpAction: MissionHpAction,
  DroneTaskControl: DroneTaskControl,
  MissionHpUpdateRadius: MissionHpUpdateRadius,
  MissionWpGetSpeed: MissionWpGetSpeed,
  QueryDroneVersion: QueryDroneVersion,
  MissionWpUpload: MissionWpUpload,
  SendMobileData: SendMobileData,
  MissionStatus: MissionStatus,
  DroneArmControl: DroneArmControl,
  MissionHpUpload: MissionHpUpload,
  MissionHpGetInfo: MissionHpGetInfo,
  SendPayloadData: SendPayloadData,
  SetLocalPosRef: SetLocalPosRef,
  SetHardSync: SetHardSync,
  MissionWpGetInfo: MissionWpGetInfo,
  Activation: Activation,
  StereoVGASubscription: StereoVGASubscription,
  MissionWpSetSpeed: MissionWpSetSpeed,
  SDKControlAuthority: SDKControlAuthority,
  StereoDepthSubscription: StereoDepthSubscription,
  MissionHpUpdateYawRate: MissionHpUpdateYawRate,
  Stereo240pSubscription: Stereo240pSubscription,
};
