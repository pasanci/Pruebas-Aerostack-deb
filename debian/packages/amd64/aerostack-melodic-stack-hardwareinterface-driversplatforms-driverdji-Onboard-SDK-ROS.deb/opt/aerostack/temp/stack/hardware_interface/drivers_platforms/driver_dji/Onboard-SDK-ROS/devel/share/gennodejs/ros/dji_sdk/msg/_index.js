
"use strict";

let WaypointList = require('./WaypointList.js');
let FlightAnomaly = require('./FlightAnomaly.js');
let MissionHotpointTask = require('./MissionHotpointTask.js');
let Gimbal = require('./Gimbal.js');
let MissionWaypoint = require('./MissionWaypoint.js');
let MissionWaypointAction = require('./MissionWaypointAction.js');
let FCTimeInUTC = require('./FCTimeInUTC.js');
let GPSUTC = require('./GPSUTC.js');
let MissionWaypointTask = require('./MissionWaypointTask.js');
let PayloadData = require('./PayloadData.js');
let VOPosition = require('./VOPosition.js');
let Waypoint = require('./Waypoint.js');
let MobileData = require('./MobileData.js');

module.exports = {
  WaypointList: WaypointList,
  FlightAnomaly: FlightAnomaly,
  MissionHotpointTask: MissionHotpointTask,
  Gimbal: Gimbal,
  MissionWaypoint: MissionWaypoint,
  MissionWaypointAction: MissionWaypointAction,
  FCTimeInUTC: FCTimeInUTC,
  GPSUTC: GPSUTC,
  MissionWaypointTask: MissionWaypointTask,
  PayloadData: PayloadData,
  VOPosition: VOPosition,
  Waypoint: Waypoint,
  MobileData: MobileData,
};
