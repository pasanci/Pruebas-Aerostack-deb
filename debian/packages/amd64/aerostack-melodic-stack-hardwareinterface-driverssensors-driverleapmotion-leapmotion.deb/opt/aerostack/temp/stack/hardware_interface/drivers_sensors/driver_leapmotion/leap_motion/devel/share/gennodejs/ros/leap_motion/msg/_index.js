
"use strict";

let leap = require('./leap.js');
let leapros = require('./leapros.js');

module.exports = {
  leap: leap,
  leapros: leapros,
};
