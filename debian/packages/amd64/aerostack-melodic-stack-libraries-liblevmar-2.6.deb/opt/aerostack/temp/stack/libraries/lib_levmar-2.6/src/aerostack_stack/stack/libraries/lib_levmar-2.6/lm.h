#ifndef _DEPR_LM_H_
#define _DEPR_LM_H_

#ifdef _MSC_VER
#pragma message("lm.h is deprecated, please use levmar.h instead!")
#else
#error lm.h is deprecated, please use levmar.h instead!
#endif /* _MSC_VER */

#endif /* _DEPR_LM_H_ */

