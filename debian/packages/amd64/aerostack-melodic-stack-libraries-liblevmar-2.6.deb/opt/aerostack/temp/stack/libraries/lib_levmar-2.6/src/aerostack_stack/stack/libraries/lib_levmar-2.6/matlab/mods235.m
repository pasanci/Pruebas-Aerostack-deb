function x = mods235(p)
  n=2;

  x(1)=0.1*(p(1)-1.0);
  x(2)=p(2)-p(1)*p(1);
