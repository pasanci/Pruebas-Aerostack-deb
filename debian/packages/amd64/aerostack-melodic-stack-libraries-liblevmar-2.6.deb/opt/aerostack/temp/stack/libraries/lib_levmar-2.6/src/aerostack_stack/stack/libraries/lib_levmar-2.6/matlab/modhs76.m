function x = modhs76(p)

  x(1)=p(1);
  x(2)=sqrt(0.5)*p(2);
  x(3)=p(3);
  x(4)=sqrt(0.5)*p(4);

