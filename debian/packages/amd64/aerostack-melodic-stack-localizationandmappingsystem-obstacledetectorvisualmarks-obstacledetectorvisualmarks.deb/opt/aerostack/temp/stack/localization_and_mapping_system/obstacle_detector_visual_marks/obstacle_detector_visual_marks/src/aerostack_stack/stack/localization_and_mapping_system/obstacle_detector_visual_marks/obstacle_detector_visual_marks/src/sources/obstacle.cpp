
#include "obstacle.h"
#include <sstream>
#include <assert.h>

