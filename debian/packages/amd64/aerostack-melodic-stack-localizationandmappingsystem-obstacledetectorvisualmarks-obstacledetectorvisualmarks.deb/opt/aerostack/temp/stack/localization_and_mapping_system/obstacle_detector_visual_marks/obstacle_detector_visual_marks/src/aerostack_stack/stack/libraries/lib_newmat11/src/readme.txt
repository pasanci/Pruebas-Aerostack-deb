   ReadMe file for newmat11 - beta version - 20 July, 2008
-------------------------------------------------------------

This is a beta version of newmat11.

Documentation is in nm11.htm.

This library is freeware. See the documentation for details.

To contact the author please email robert@statsresearch.co.nz


