#include "rectangle.h"
#include <math.h>

/*
Rectangle::Rectangle()
{

}
*/



