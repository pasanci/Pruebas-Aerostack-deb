
"use strict";

let SoundRequestResult = require('./SoundRequestResult.js');
let SoundRequestAction = require('./SoundRequestAction.js');
let SoundRequestActionFeedback = require('./SoundRequestActionFeedback.js');
let SoundRequestActionGoal = require('./SoundRequestActionGoal.js');
let SoundRequestFeedback = require('./SoundRequestFeedback.js');
let SoundRequestGoal = require('./SoundRequestGoal.js');
let SoundRequestActionResult = require('./SoundRequestActionResult.js');
let SoundRequest = require('./SoundRequest.js');

module.exports = {
  SoundRequestResult: SoundRequestResult,
  SoundRequestAction: SoundRequestAction,
  SoundRequestActionFeedback: SoundRequestActionFeedback,
  SoundRequestActionGoal: SoundRequestActionGoal,
  SoundRequestFeedback: SoundRequestFeedback,
  SoundRequestGoal: SoundRequestGoal,
  SoundRequestActionResult: SoundRequestActionResult,
  SoundRequest: SoundRequest,
};
