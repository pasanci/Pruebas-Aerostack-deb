
"use strict";

let AudioData = require('./AudioData.js');

module.exports = {
  AudioData: AudioData,
};
